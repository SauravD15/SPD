Recommended Data Source

- Connect to `data/sales.csv` directly OR to database view `v_sales_enriched`.

Calculated Fields

- Revenue: SUM([unit_price] * [quantity] * (1 - ZN([discount_pct])))
- Gross Margin: SUM(([unit_price] - [unit_cost]) * [quantity])
- AOV: SUM([Revenue]) / COUNTD([order_id])
- Order Month: DATETRUNC('month', [order_date])

Suggested Sheets

- Monthly Revenue Trend (line)
- Revenue by Region (map or bar)
- Category Performance (stacked bar)
- Top 10 Products by Revenue (bar)
- KPI Tiles: Revenue, Units Sold, AOV, Gross Margin

Dashboard

- Filter panel: Month, Region, Category, Store
- Interactivity: Click-through from Region to Store to Product

Publishing

- Export as PDF or publish to Tableau Public for portfolio.


